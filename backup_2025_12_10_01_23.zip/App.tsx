
import React, { useState } from 'react';
import { UserProfile, GameData, ViewState, CriticalMoment, ErrorType } from './types';
import Dashboard from './components/Dashboard';
import AnalysisView from './components/AnalysisView';
import CriticalChallenge from './components/CriticalChallenge';
import TacticalTraining from './components/TacticalTraining';
import LandingPage from './components/LandingPage';
import PGNViewer from './components/PGNViewer';
import { analyzeGame } from './services/analysisService';
import { Layout, FileText, X } from 'lucide-react';

const App: React.FC = () => {
  // Inicializamos en 'landing' para mostrar la portada primero
  const [view, setView] = useState<ViewState>('landing');
  const [profile] = useState<UserProfile>({ name: 'LuChess', elo: 1550 });

  const [history, setHistory] = useState<GameData[]>([]);
  const [activeGame, setActiveGame] = useState<GameData | null>(null);
  const [activeMoment, setActiveMoment] = useState<CriticalMoment | null>(null);
  const [pgnInput, setPgnInput] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Navigation handlers
  const goToDashboard = () => setView('dashboard');

  const handlePgnUpload = async () => {
    if (!pgnInput.trim()) return;
    setIsAnalyzing(true);
    try {
      const data = await analyzeGame(pgnInput, profile.name);
      setHistory(prev => [...prev, data]);
      setActiveGame(data);
      setView('analysis');
    } catch (error) {
      alert("Error analizando PGN. Por favor revisa el formato.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) setPgnInput(event.target.result as string);
    };
    reader.readAsText(file);
  };


  const handleDirectPgnLoad = async (pgn: string, mode: 'analysis' | 'viewer') => {
    if (!pgn) return;

    if (mode === 'analysis') {
      setIsAnalyzing(true);
      try {
        const data = await analyzeGame(pgn, profile.name);
        setHistory(prev => [...prev, data]);
        setActiveGame(data);
        setView('analysis');
      } catch (error) {
        alert("Error analizando PGN.");
      } finally {
        setIsAnalyzing(false);
      }
    } else {
      // Viewer Mode
      setPgnInput(pgn); // Reusing this state to pass to Viewer
      setView('visor');
    }
  };

  // Renderizado condicional para la Landing Page fuera del Layout principal de la app
  if (view === 'landing') {
    return <LandingPage onEnterApp={goToDashboard} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-green-500/30">
      {/* Navigation Bar */}
      <nav className="h-16 border-b border-slate-800 bg-slate-900/50 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">

          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView('landing')}>
            <Layout className="text-green-500 w-6 h-6" />

            <span className="text-xl font-bold text-white tracking-tight">CentaUros<span className="text-green-500">Chess</span></span>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-sm text-slate-400 hidden sm:block">
              <span className="hidden sm:inline">Estado del Motor: </span>
              <span className="text-green-400 font-mono text-xs border border-green-900 bg-green-900/20 px-2 py-0.5 rounded">EN LÍNEA</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-white">{profile.name}</span>
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-500 to-blue-600 border border-slate-600"></div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="min-h-[calc(100vh-64px)]">

        {/* VIEW: DASHBOARD */}
        {view === 'dashboard' && (
          <Dashboard
            profile={profile}
            history={history}
            onUploadClick={() => setView('upload')}
            onTrainingClick={() => setView('training')}
            onVisorClick={() => setView('visor')}
            onDirectPgnLoad={handleDirectPgnLoad}
          />
        )}

        {/* VIEW: UPLOAD */}
        {view === 'upload' && (
          <div className="max-w-2xl mx-auto mt-12 p-6 bg-slate-800 rounded-xl border border-slate-700 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Subir Partida</h2>
              <button onClick={goToDashboard} className="text-slate-400 hover:text-white"><X /></button>
            </div>

            <div className="space-y-4">
              <div className="border-2 border-dashed border-slate-600 rounded-lg p-8 text-center hover:bg-slate-700/50 transition-colors">
                <input type="file" accept=".pgn" onChange={handleFileUpload} className="hidden" id="pgn-file" />
                <label htmlFor="pgn-file" className="cursor-pointer flex flex-col items-center gap-2">
                  <FileText className="w-8 h-8 text-green-400" />
                  <span className="text-slate-300 font-medium">Clic para subir archivo .pgn</span>
                </label>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-700"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-slate-800 text-slate-500">O pegar texto</span>
                </div>
              </div>

              <textarea
                className="w-full h-40 bg-slate-900 border border-slate-700 rounded-lg p-4 font-mono text-sm focus:ring-2 focus:ring-green-500 outline-none text-slate-300"
                placeholder="[Event '...'] 1. e4 e5 ..."
                value={pgnInput}
                onChange={(e) => setPgnInput(e.target.value)}
              />

              <button
                disabled={isAnalyzing || !pgnInput}
                onClick={handlePgnUpload}
                className="w-full bg-green-600 hover:bg-green-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-3 rounded-lg transition-all"
              >
                {isAnalyzing ? 'Analizando con Stockfish...' : 'Analizar Partida'}
              </button>
            </div>
          </div>
        )}

        {/* VIEW: ANALYSIS */}
        {view === 'analysis' && activeGame && (
          <div className="h-[calc(100vh-64px)] p-6">
            <div className="max-w-7xl mx-auto h-full flex flex-col gap-4">
              <div className="flex items-center gap-4">
                <button onClick={goToDashboard} className="text-slate-400 hover:text-white text-sm">← Volver al Dashboard</button>
                <h2 className="text-xl font-bold text-white">Resultados del Análisis</h2>
              </div>
              <div className="flex-1">
                <AnalysisView
                  game={activeGame}
                  onStartChallenge={(moment) => {
                    setActiveMoment(moment);
                    setView('challenge');
                  }}
                />
              </div>
            </div>
          </div>
        )}

        {/* VIEW: CHALLENGE */}
        {view === 'challenge' && activeMoment && (
          <CriticalChallenge
            key={activeMoment.fen} // IMPORTANTE: Esta key fuerza el reseteo del componente cuando cambia el FEN
            moment={activeMoment}
            onComplete={() => { }}
            onExit={() => setView('analysis')}
          />
        )}

        {/* VIEW: TRAINING */}
        {view === 'training' && (
          <div className="py-12 px-4">
            <div className="max-w-4xl mx-auto mb-4">
              <button onClick={goToDashboard} className="text-slate-400 hover:text-white text-sm">← Volver al Dashboard</button>
            </div>
            <TacticalTraining
              errorType={history.length > 0 ? history[history.length - 1].dominantError : ErrorType.TACTICAL_GRAVE}
              onClose={goToDashboard}
            />
          </div>
        )}

        {/* VIEW: VISOR */}
        {view === 'visor' && (
          <PGNViewer onBack={goToDashboard} initialPgn={pgnInput} />
        )}

      </main>
    </div>
  );
};

export default App;
